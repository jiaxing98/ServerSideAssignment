package service;

import java.math.BigInteger;
import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import domain.Employee;
import domain.Office;


@Dependent
@Transactional
public class EmployeeService implements EmployeeServiceInterface{

	private EntityManager em;

	@Inject
	public EmployeeService(@PostGresDatabase EntityManager em) {
		this.em = em;
	}

	public List<Employee> getAllEmployees() throws EJBException {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Employee.findAll").getResultList();
	}

	public List<Employee> readStaff(int currentPage, int recordsPerPage, String keyword) throws EJBException {
		// Write some codes here�
		Query q = null;
		if (keyword.isEmpty()) {
			q = em.createNativeQuery("select * from classicmodels.employees order by employeenumber OFFSET ? LIMIT ?",
					Employee.class);
			int start = currentPage * recordsPerPage - recordsPerPage;
			q.setParameter(1, Integer.valueOf(start));
			q.setParameter(2, Integer.valueOf(recordsPerPage));
		} else {
			q = em.createNativeQuery(
					"SELECT * from classicmodels.employees WHERE concat(employeenumber,lastname,firstname,extension) LIKE? order by id OFFSET ? LIMIT ?",
					Employee.class);
			int start = currentPage * recordsPerPage - recordsPerPage;
			q.setParameter(1, "%" + keyword + "%");
			q.setParameter(2, Integer.valueOf(start));
			q.setParameter(3, Integer.valueOf(recordsPerPage));
		}
		List<Employee> results = q.getResultList();
		return results;
	}

	public int getNumberOfRows(String keyword) throws EJBException {
		// Write some codes here�
		Query q = null;
		if (keyword.isEmpty()) {
			q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.employees");
		} else {
			q = em.createNativeQuery(
					"SELECT COUNT(*) AS totalrow from classicmodels.employees WHERE concat(employeenumber,lastname,firstname,extension) LIKE ?");
			q.setParameter(1, "%" + keyword + "%");
		}
		BigInteger results = (BigInteger) q.getSingleResult();
		int i = results.intValue();
		return i;
	}

	public Employee findEmployee(String id) throws EJBException {
		// Write some codes here�
		Query q = em.createNamedQuery("Employee.findbyId");
		q.setParameter("id", Long.valueOf(id));
		return (Employee) q.getSingleResult();
	}

	public void updateEmployee(String[] s) throws EJBException {
		// Write some codes here�
		Employee e = findEmployee(s[0]);
		
		e.setLastname(s[1]);
		e.setFirstname(s[2]);
		e.setExtension(s[3]);
		e.setEmail(s[4]);
		e.setReportsto(s[5]);
		e.setJobtitle(s[6]);
		e.setUsername(s[7]);

		em.merge(e);
	}

	public void deleteEmployee(String id) throws EJBException {
		// Write some codes here�
		Employee e = findEmployee(id);
		em.remove(e);
	}

	public void addEmployee(String[] s) throws EJBException {
		// Write some codes here�
		
		Employee e = new Employee();

		e.setLastname(s[1]);
		e.setFirstname(s[2]);
		e.setExtension(s[3]);
		e.setEmail(s[4]);
		//e.setOffice(office);
		e.setReportsto(s[5]);
		e.setJobtitle(s[6]);
		e.setUsername(s[7]);
		em.persist(e);
	}

}
